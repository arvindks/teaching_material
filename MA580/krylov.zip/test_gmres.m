clear all
clc
close all


%% This example heavily borrows from MATLAB's gmres documentation
load west0479;
A = west0479;


tol = 1e-15;
maxit = 300;

xt = ones(size(A,1),1);
b = full(sum(A,2));



%% GMRES unpreconditioned
% No restarting

[x0,fl0,rr0,it0,rv0] = gmres(A,b,[],tol,maxit);
figure
semilogy(0:maxit,rv0/norm(b),'-o');
xlabel('Iteration number');
ylabel('Relative residual');

set(gca, 'FontSize', 16)
title('No preconditioner')
%fprintf('Relative error is %g.\n', norm(xt-x0)/norm(xt));

%% GMRES with preconditioner
[L,U] = ilu(A,struct('type','ilutp','droptol',1e-6));
[x1,fl1,rr1,it1,rv1] = gmres(A,b,[],tol,maxit,L,U);
figure
semilogy(1:length(rv0),rv0/norm(b),'-o'); hold on
semilogy(1:length(rv1),rv1/norm(b),'r-.');
xlabel('Iteration number');
ylabel('Relative residual');
legend('No Preconditioner', 'Preconditioner')
title('Effect of preconditioner')
set(gca, 'FontSize', 16)


%% GMRES No preconditioner, different restart parameters
m = 10:5:25;
maxit = 10;
res = {};
figure
for j = 1:length(m)
    [xr,flr,rrr,itr,rvr] = gmres(A,b,m(j),tol,maxit);
    semilogy(1:length(rvr),rvr/norm(b)); hold on
    res{j} = strcat('m = ', num2str(m(j)));
end
xlabel('Iteration number');
ylabel('Relative residual');
legend(res)
set(gca, 'FontSize', 16)



%% Preconditioner and restarting
tol = 1e-12;
maxit = 20;
re3 = 3;
[x3,fl3,rr3,it3,rv3] = gmres(A,b,re3,tol,maxit,L,U);
re4 = 4;
[x4,fl4,rr4,it4,rv4] = gmres(A,b,re4,tol,maxit,L,U);
re5 = 5;
[x5,fl5,rr5,it5,rv5] = gmres(A,b,re5,tol,maxit,L,U);

figure
semilogy(1:1/3:6,rv3/norm(b),'-o');
h1 = gca;
h1.XTick = [1:1/3:6];
h1.XTickLabel = ['1';' ';' ';'2';' ';' ';'3';' ';' ';'4';' ';' ';'5';' ';' ';'6';];
title('gmres(3)')
xlabel('Iteration number');
ylabel('Relative residual');
set(gca, 'FontSize', 16)


figure
semilogy(1:1/4:3,rv4/norm(b),'-o');
h2 = gca;
h2.XTick = [1:1/4:3];
h2.XTickLabel = ['1';' ';' ';' ';'2';' ';' ';' ';'3'];
title('gmres(4)')
xlabel('Iteration number');
ylabel('Relative residual');
set(gca, 'FontSize', 16)

%fprintf('Relative error is %g.\n', norm(xt-x5)/norm(xt));
