clear all
clc
close all


%% Solve the Poisson's equation - Delta u = f with
% Dirichlet boundary conditions

A = delsq(numgrid('S',500));
b = ones(size(A,1),1);

% No preconditioner
tic
[x0,fl0,rr0,it0,rv0] = pcg(A,b,1e-8,1000);
tnp = toc;
fprintf('Time without preconditioner is %g.\n', tnp)


% Use Incomplete Cholesky as preconditioner
L = ichol(A);
tic
[x1,fl1,rr1,it1,rv1] = pcg(A,b,1e-8,1000,L,L');
tichol = toc;
fprintf('Time with ICC as preconditioner is %g.\n', tichol)


% Use Modified Incomplete Cholesky
L = ichol(A,struct('michol','on'));
tic
[x2,fl2,rr2,it2,rv2] = pcg(A,b,1e-8,1000,L,L');
tmichol = toc;
fprintf('Time with MICC as preconditioner is %g.\n', tmichol)




%% GMRES on the same matrix
L = ichol(A,struct('michol','on'));
tic
[x3,fl3,rr3,it3,rv3] = gmres(A,b,30,1e-8,100,L,L');
tmichol = toc;
fprintf('Time with GMRES ICC as preconditioner is %g.\n', tmichol)



%%
figure;
semilogy(0:it0,rv0/norm(b),'b.');
hold on;
semilogy(0:it1,rv1/norm(b),'r.');
semilogy(0:it2,rv2/norm(b),'k.');
semilogy(0:it2,rv2/norm(b),'go');

legend('No Preconditioner','IC(0)','MIC(0)', 'GMRES(30) - MIC(0)');
xlabel('iteration number');
ylabel('relative residual');
hold off;
set(gca, 'FontSize', 16)