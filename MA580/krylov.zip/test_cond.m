clear all
clc
close all


%% Conjugate gradient and condition number
kappa = 10.^(1:6);
leg = {};
for j = 1:length(kappa)
    leg{j} = strcat('\kappa = ', num2str(kappa(j)));
end
figure,
for j = 1:length(kappa)
    A = gallery('randsvd',128,-kappa(j),3);
    b = ones(128,1);
    
    
    [x,flag,relres,iter,rv] = pcg(A,b,1.e-8,1000);
    semilogy(rv), hold on
end
set(gca, 'FontSize', 16)
xlabel('Iterations', 'FontSize',18)
ylabel('Relative Residual', 'FontSize', 18)
legend(leg)
title('Convergence of Conjugate Gradient', 'FontSize', 20)

%% GMRES and condition number
% we choose a restart parameter of 30
kappa = 10.^(1:6);
figure,
for j = 1:length(kappa)
    A = gallery('randsvd',128,-kappa(j),3);
    b = ones(128,1);
    
    [x,flag,relres,iter,rv] = gmres(A,b,30,1.e-6,100);
    semilogy(1:length(rv),rv, 'DisplayName', strcat('kappa = ', num2str(kappa(j)))), hold on
end
set(gca, 'FontSize', 16)
xlabel('Iterations', 'FontSize',18)
ylabel('Relative Residual', 'FontSize', 18)
title('Convergence of GMRES(30)', 'FontSize', 20)
legend(leg)